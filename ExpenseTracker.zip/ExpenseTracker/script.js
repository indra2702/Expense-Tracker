let transactions = []
let budget = 0
let myChart

function setBudget(){
  budget = Number(document.getElementById("budgetInput").value)

  if(budget <= 0){
    alert("Enter valid budget")
    return
  }

  document.getElementById("budgetDisplay").innerText = budget

  updateSummary()
}

function addExpense(){
  if(budget === 0){
    alert("Please set budget first")
    return
  }

  let desc = document.getElementById("desc").value.trim()
  let amount = Number(document.getElementById("amount").value)

  let customCategory = document.getElementById("customCategory").value.trim()
  let category = customCategory || document.getElementById("category").value

  if(desc === "" || amount <= 0){
    alert("Enter valid description and amount")
    return
  }

  transactions.push({
    desc: desc,
    amount: amount,
    category: category
  })

  showTransactions()
  updateSummary()
  drawChart()

  document.getElementById("desc").value = ""
  document.getElementById("amount").value = ""
  document.getElementById("customCategory").value = ""
}

function updateSummary(){
  let spent = 0

  transactions.forEach(t=>{
    spent += t.amount
  })

  document.getElementById("spentDisplay").innerText = spent

  let remaining = budget - spent

  document.getElementById("remainingDisplay").innerText = remaining

  if(budget > 0){
    let percent = (spent / budget) * 100
    if(percent > 100) percent = 100

    document.getElementById("progressBar").style.width = percent + "%"
  }

  if(spent > budget){
    alert("⚠️ Warning: Your expense has exceeded the budget!")
  }
}

function showTransactions(){
  let list = document.getElementById("transactionList")

  list.innerHTML = ""

  transactions.forEach(t=>{
    let li = document.createElement("li")
    li.innerText = `${t.desc} - ₹${t.amount} (${t.category})`
    list.appendChild(li)
  })
}

function drawChart(){
  let categories = {}

  transactions.forEach(t=>{
    if(!categories[t.category]){
      categories[t.category] = 0
    }
    categories[t.category] += t.amount
  })

  let ctx = document.getElementById("chart")

  if(myChart){
    myChart.destroy()
  }

  myChart = new Chart(ctx,{
    type: "doughnut",
    data: {
      labels: Object.keys(categories),
      datasets: [{
        data: Object.values(categories)
      }]
    }
  })
}

function resetData(){
  transactions = []
  budget = 0

  document.getElementById("budgetDisplay").innerText = 0
  document.getElementById("spentDisplay").innerText = 0
  document.getElementById("remainingDisplay").innerText = 0
  document.getElementById("transactionList").innerHTML = ""

  if(myChart){
    myChart.destroy()
  }
}

function downloadPDF(){
  const { jsPDF } = window.jspdf

  let doc = new jsPDF()

  doc.text("Expense Report", 20, 20)

  let y = 40

  transactions.forEach(t=>{
    doc.text(`${t.desc} - ₹${t.amount} (${t.category})`, 20, y)
    y += 10
  })

  doc.save("expense_report.pdf")
}